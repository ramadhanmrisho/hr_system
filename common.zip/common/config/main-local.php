<?php
return [
    'components' => [
//        'db' => [
//            'class' => 'yii\db\Connection',
//            'dsn' => 'mysql:host=localhost;dbname=kcohas',
//            'username' => 'root',
//            'password' => '',
//            'charset' => 'utf8',
//        ],
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=127.0.0.1;dbname=hr_mis_1',
            'username' => 'root',
            'password' => '',
            'charset' => 'utf8',
        ],

//        'db' => [
//            'class' => \yii\db\Connection::class,
//            'dsn' => 'mysql:host=154.118.224.21;dbname=klm',
//            'username' => 'klm',
//            'password' => 'Newuser@123',
//            'charset' => 'utf8',
//        ],

        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'transport'=>[
                'class'=>'Swift_SmtpTransport',
                'host'=>'smtp.gmail.com',
                'username'=>'rama.mrisho72@gmail.com',
                'password'=>"@0753894468",
                'port' => '465',
                'encryption' => 'ssl' ,
            ],
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            //'useFileTransport' => false,
        ],
    ],
];
