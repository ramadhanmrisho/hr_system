Change Log: `yii2-bootstrap4-dropdown`
======================================

## Version 1.0.1

**Date:** 27-Mar-2020

- Configure composer yii2-bootstrap4 dependency under SUGGEST (remove explicit dependency).
- Correct dropdown styling for buttons and non-navbars.

## Version 1.0.0

**Date:** 16-Sep-2018

- Initial release