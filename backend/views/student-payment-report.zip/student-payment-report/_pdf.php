<?php /** @var string $url */?>
<?php /** @var string $name */?>
<?php /** @var string $is_docx */?>
<a id="pdf-url" href="<?= $url?>" class="<?= $is_docx?'is-docx':'is-pdf'?>"></a>
<h4><?=$name?></h4>